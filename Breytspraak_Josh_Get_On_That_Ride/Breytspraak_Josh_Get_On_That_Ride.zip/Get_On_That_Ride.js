//If the rider's height is greater than 42, the console.log should say "Get on that ride, kiddo!". 
//Otherwise, console.log should say "Sorry kiddo. Maybe next year."





let age = 10;
let height = 42;
if (age >= 10 && height >= 42) {
    console.log("Get on that ride, kiddo!");
}
else if(age <= 10 || height < 42){
    console.log("Sorry kiddo. Maybe next year!")
}
